﻿#!/usr/bin/python
import sys, os, xbmc, xbmcplugin
from .base2 import _Base2
from kodipopcorntime.settings import BUILD, QUALITIES, addon as _settings
from kodipopcorntime.logging import log, log_error
from kodipopcorntime.utils import xbmcItem, clear_cache

__addon__ = sys.modules['__main__'].__addon__

class _Base3(_Base2):
    def __init__(self, *args):
        super(_Base3, self).__init__(*args)
        try:
            update_id = "%s.%s" %(_settings.version, BUILD)
            if not update_id == _settings.last_update_id:
                # Clear cache after update
                clear_cache()
                __addon__.setSetting("last_update_id", update_id)
        except:
            log_error()
            sys.exc_clear()

    def getOpenSettings(self):
        return (__addon__.getLocalizedString(30010), 'Addon.OpenSettings(%s)' %_settings.id)

    def addItem(self, item, path, isFolder=True):
        if not isFolder:
            item["context_menu"] = []
            for _q in QUALITIES:
                if "&%s=" %_q in path:
                    item["context_menu"] = item["context_menu"]+[('%s %s' %(__addon__.getLocalizedString(30009), _q), 'RunPlugin(%s&quality=%s)' %(path, _q))]
            item["context_menu"] = item["context_menu"]+[self.getOpenSettings()]
            item["replace_context_menu"] = True
        super(_Base3, self).addItem(item, path, isFolder)

    def getCurPageNum(self):
        return int(xbmc.getInfoLabel("ListItem.Property(pageNum)") or 1)

    def addNextButton(self, **kwargs):
        log("(%s) Adding item 'Show more'" %self.interfaceName)

        item = {
            "label": __addon__.getLocalizedString(30000),
            "icon": os.path.join(_settings.resources_path, 'media', self.mediaSettings.mediaType, 'more.png'),
            "thumbnail": os.path.join(_settings.resources_path, 'media', self.mediaSettings.mediaType, 'more_thumbnail.png'),
            "replace_context_menu": True,
            "context_menu": [self.getOpenSettings()],
            "properties": {
                "fanart_image": _settings.fanart
            }
        }
        item.setdefault('properties').update(dict((key, str(value)) for key, value in kwargs.items() if value))
        xbmcplugin.addDirectoryItem(_settings.handle, "%s?%s" %(_settings.base_url, _settings.cur_uri), xbmcItem(**item), True)
